// Filename: Arc.java
// Author: Miles Clikeman

import java.util.*;
import java.io.*;

// *****************************************************************************
// *****************************************************************************
// **** Arc
// *****************************************************************************
// *****************************************************************************

public class Arc {

  // left and right endpoints of arc, nesting number of arc
  private int myLeft, myRight, myNestingNumber;

  public Arc(int left, int right, int nesting) {
    this.myLeft = left;
    this.myRight = right;
    this.myNestingNumber = nesting;
  } // end Arc constructor


  public Arc(int left, int right) {
    this(left, right, 0);
  } // end Arc constructor


  // return left endpoint of arc
  public int getLeft() { 
    return myLeft; 
  } // end of getLeft

  
  // return right endpoint of arc
  public int getRight() { 
    return myRight;
  } // end of getRight

  
  // return nesting number of arc
  public int getNestingNumber() { 
    return myNestingNumber; 
  } // end of getDepth

  
  // add one to nesting number of arc
  public void incrementNestingNumber() { 
    ++myNestingNumber; 
  } // end of incrementDepth


  // return whether this arc contains the other arc
  public boolean contains(Arc other) {
    return (myLeft <= other.getLeft() && myRight >= other.getRight());
  } // end of contains
  
  
} // end of Arc class
