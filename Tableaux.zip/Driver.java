// Filename: Driver.java
// Author: Miles Clikeman

import java.util.*;

// *****************************************************************************
// *****************************************************************************
// **** Drive
// *****************************************************************************
// *****************************************************************************

public class Driver {

  public static void main(String[] args) {
    
    Scanner console = new Scanner(System.in);
    
    // read in n
    System.out.print("Enter n (1-9): ");
    int n = console.nextInt();

    // create Young Tableaux of size n
    YoungTableau yt;
    yt = new YoungTableau(n);

  } // main

} // end of Driver class
