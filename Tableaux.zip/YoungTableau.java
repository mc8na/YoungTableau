// Filename: YoungTableau.java
// Author: Miles Clikeman

import java.util.*;
import java.io.*;
import java.lang.*;

// *****************************************************************************
// *****************************************************************************
// **** YoungTableau
// *****************************************************************************
// *****************************************************************************

public class YoungTableau {

  private int[] myRanks; // stores ranks
  private ArrayList<Shadow> myShadows; // stores shadows
  private int[][] myTableau;
  private int myN, threeN, id, numTableau;

  private ArrayList<IDPair> myAnomolies; // stores id pairs


  public YoungTableau(int n) {
    this.myN = n;
    this.threeN = 3*n;
    this.numTableau = Dimension.getDimension(n); // number of SYT of size (n,n,n)
    this.myRanks = new int[numTableau];
    this.myShadows = new ArrayList<Shadow>(numTableau);
    this.myTableau = new int[3][n];
    this.myAnomolies = new ArrayList<IDPair>();
    id = 0;
    //System.out.println("computing ranks and shadows");
    generateTableauData(0, 0, 0);
    //System.out.println("finding anomolies");
    findAnomolies();
    //System.out.println("printing anomolies");
    printAnomolies();
  } // end YoungTableau constructor


  
  // recursively generates all SYT of size (n,n,n) and call computeMyRankAndShadow
  // on each tableaux
  private void generateTableauData(int row1, int row2, int row3) {
    int numElements = row1 + row2 + row3;

    if (numElements == threeN) {
      computeMyRankAndShadow(myTableau);
      ++id; // increment id for next tableau
    } else {
      if (row1 < myN) { // try adding element to row 1
        myTableau[0][row1] = numElements + 1;
        generateTableauData(row1 + 1, row2, row3);
      } // end if
      if (row2 < row1) { // try adding element to row 2
        myTableau[1][row2] = numElements + 1;
        generateTableauData(row1, row2 + 1, row3);
      } // end if
      if (row3 < row2) { // try adding element to row 3
        myTableau[2][row3] = numElements + 1;
        generateTableauData(row1, row2, row3 + 1);
      } // end if
    } // end else
  } // end generateTableauData

  
  // computes and prints the rank and shadow of the input (n,n,n) tableaux
  private void printRankAndShadow(int[][] tableau) {
    int n = tableau[0].length;

    Shadow shadow = new Shadow();
      
    int left, right;
    int rank = -n; // account for -1 part of depth-1 for each "0"
    boolean[] paired = new boolean[n]; // store whether "+" is paired

    for (int i = 0; i < n; ++i) { // for each "-"
      int j = n-1;
      // find closest unpaired "+" to the left
      while (paired[j] || tableau[2][i] < tableau[0][j]) {
        --j;
      } // end while
      paired[j] = true;

      left = tableau[0][j];
      right = tableau[2][i];

      // create arc between endpoints and add to shadow
      shadow.addArc(new Arc(left,right));

      // increment rank for each "0" contained in the new arc
      for (int k = 0; k < n; ++k) {
        if (tableau[1][k] > left && tableau[1][k] < right) {
          ++rank;
        } // end if
      } // end for

    } // end for

    // compute nesting numbers of arcs
    shadow.computeNestingNumbers();
    
    // add sum of nesting to rank
    rank += shadow.sumOfNestingNumbers();

    // print rank and shadow
    System.out.println("rank: " + rank);
    System.out.println("shadow:");
    shadow.print();
  } // end printRankAndShadow


  // compute rank and shadow of input tableau and store in myRanks and myShadows
  private void computeMyRankAndShadow(int[][] tableau) {
    int n = tableau[0].length;

    Shadow shadow = new Shadow();
      
    int left, right;
    myRanks[id] = -n; // account for -1 part of depth-1 for each "0"
    boolean[] paired = new boolean[n]; // store whether "+" is paired
    for (int i = 0; i < n; ++i) { // for each "-"
      int j = n-1;
      // find closest unpaired "+" to the left
      while (paired[j] || tableau[2][i] < tableau[0][j]) {
        --j;
      } // end while
      paired[j] = true;

      left = tableau[0][j];
      right = tableau[2][i];

      // create arc between endpoints and add to shadow
      shadow.addArc(new Arc(left,right));

      // increment rank for each "0" contained in the new arc
      for (int k = 0; k < n; ++k) {
        if (tableau[1][k] > left && tableau[1][k] < right) {
          myRanks[id] = myRanks[id] + 1;
        } // end if
      } // end for

    } // end for

    // compute nesting numbers of arcs
    shadow.computeNestingNumbers();

    // add sum of nesting to rank
    myRanks[id] = myRanks[id] + shadow.sumOfNestingNumbers();
      
    // add shadow to myShadows
    myShadows.add(id,shadow);

  } // end computeMyRankAndShadow

  
  // find all pairs (b,b') of SYT of size (n,n,n) such that rank(b) < rank(b')
  // and shadow(b) contains shadow(b') and add them to myAnomolies
  private void findAnomolies() {
    for (int i = 0; i < numTableau; ++i) {
      for (int j = i+1; j < numTableau; ++j) {
        if ( (myRanks[i] < myRanks[j] && myShadows.get(i).contains(myShadows.get(j))) ||
             (myRanks[j] < myRanks[i] && myShadows.get(j).contains(myShadows.get(i))) ){
          IDPair pair = new IDPair(i,j);
          myAnomolies.add(pair);
        } // end if
      } // end for
    } // end for
  } // end findAnomolies


  // print rank, shadow, and tableau of each pair (b,b') of SYT of size (n,n,n)
  // such that rank(b) < rank(b') and shadow(b) contains shadow(b')
  private void printAnomolies() {
    if (myAnomolies.size() == 0) {
      System.out.println("No anomolies found for Young Tableau");
      System.out.println("  of size (" + myN + "," + myN + "," + myN + ")");
    } else {
      for (IDPair pair : myAnomolies) { // for each pair of tableau
        int first = pair.getFirst();
        int second = pair.getSecond();

        System.out.println("id: " + first);
        System.out.println("rank: " + myRanks[first]);
        System.out.println("shadow:");
        myShadows.get(first).print();
        printTableau(first);

        System.out.println();
        System.out.println();

        System.out.println("id: " + second);
        System.out.println("rank: " + myRanks[second]);
        System.out.println("shadow:");
        myShadows.get(second).print();
        printTableau(second);

        System.out.println();
        System.out.println("-------------------------");
        System.out.println();
      }
      System.out.print(myAnomolies.size() + " anomolies found for Young Tableau");
      System.out.println(" of size (" + myN + "," + myN + "," + myN + ")");
    } // end for
  } // end printAnomolies

  
  // print the tableau with the given id number
  private void printTableau(int tabId) {
    
    // use the shadow to reconstruct the tableau
    Shadow shadow = myShadows.get(tabId);

    int[] plus = new int[myN]; // first row of tableau
    int[] zero = new int[myN]; // second row
    int[] minus = new int[myN]; // third row
    // store which numbers 1,2,...,3n have been accounted for
    boolean[] used = new boolean[threeN];
    int idx = 0;
    int temp;
    for (Arc arc : shadow.arcs()) { // for each arc
      temp = arc.getLeft();
      plus[idx] = temp; // add left endpoint to first row
      used[temp-1] = true;

      temp = arc.getRight(); // add right endpoint to third row
      minus[idx] = temp;
      used[temp-1] = true;
      ++idx;
    } // end for

    // sort first and third rows in increasing order
    Arrays.sort(plus);
    Arrays.sort(minus);

    idx = 0;
    // fill second row with numbers not in first and third rows
    for (int i = 0; i < threeN; ++i) {
      if (!used[i]) {
        zero[idx] = i+1;
        ++idx;
      } // end if
    } // end for

    // print first row
    for (int i = 0; i < myN; ++i) {
      System.out.printf("%3d ", plus[i]);
    } // end for
    System.out.println();

    // print second row
    for (int i = 0; i < myN; ++i) {
      System.out.printf("%3d ", zero[i]);
    } // end for
    System.out.println();

    // print third row
    for (int i = 0; i < myN; ++i) {
      System.out.printf("%3d ", minus[i]);
    } // end for
    System.out.println();
    

  } // end printTableau
  
  
} // end of YoungTableau class
