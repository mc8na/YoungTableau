// Filename: Shadow.java
// Author: Miles Clikeman

import java.util.*;
import java.io.*;

// *****************************************************************************
// *****************************************************************************
// **** Shadow
// *****************************************************************************
// *****************************************************************************

public class Shadow {

  private ArrayList<Arc> myArcs; // stores the arcs in the shadow


  // constructor
  public Shadow(/* int numLevels */) {
    myArcs = new ArrayList<Arc>(/* numLevels */);
  } // end Shadow constructor


  // return iterator over arcs in shadow
  public Iterable<Arc> arcs() {
    return myArcs;
  }


  // add an arc to the shadow
  public void addArc(Arc newArc) { 
    myArcs.add(newArc); 
  } // end of addArc


  // computes the nesting numbers of each arc in the shadow
  public void computeNestingNumbers() {
    int size = myArcs.size();
    for (int i = 0; i < size; ++i) {
      for (int j = 0; j < size; ++j) {
        if (j != i && myArcs.get(j).contains(myArcs.get(i))) {
          myArcs.get(i).incrementNestingNumber();
        } // end if
      } // end for
    } // end for
  } // end computeDepths


  // returns the sum of the nesting numbers of the arcs in the shadow
  public int sumOfNestingNumbers() {
    int sum = 0;
    for (Arc arc : myArcs) {
      sum += arc.getNestingNumber();
    }
    return sum;
  } // end sumOfDepths

  
  // return whether this shadow contains the input shadow
  public boolean contains(Shadow other) { 
    for (Arc arc1 : other.myArcs) {
      boolean contains = false;
      for (Arc arc2 : this.myArcs) {
        if (arc1.getNestingNumber() == arc2.getNestingNumber() && arc2.contains(arc1)) {
          contains = true;
        } // endi f
      } // end for
      if (contains == false) {
        return false;
      }

    } // end for
    return true;
  } // end of contains


  // prints the nested sequence of intervals at each nesting number in the shadow
  public void print() {
    int size = myArcs.size();
    for (int i = 0; i < size; ++i) { // for each nesting number
      System.out.print("s" + (i+1) + " = {");
      boolean prior = false;
      for (Arc arc : myArcs) { // for each arc
        if (arc.getNestingNumber() == i) { // if arc has right nesting number
          if (prior) {
            System.out.print(",");
          } // end if
          System.out.print("(" + arc.getLeft() + "," + arc.getRight() + ")");
          prior = true;
        } // end if
      } // end for
      System.out.println("}");
    } // end for
  } // end print
  
  
} // end of Shadow class
